
import React from "react";

const Learn: React.FC = () => {
  return (
    <div className="p-8">
      <h1>Learn</h1>
    </div>
  );
};

export default Learn;
