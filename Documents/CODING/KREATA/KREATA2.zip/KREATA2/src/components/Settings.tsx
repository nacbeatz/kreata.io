
import React from "react";

const Settings: React.FC = () => {
  return (
    <div className="p-8">
      <h1>Settings</h1>
    </div>
  );
};

export default Settings;
