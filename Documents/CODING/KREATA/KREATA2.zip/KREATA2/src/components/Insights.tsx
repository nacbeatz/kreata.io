// src/components/Channels.tsx
import React from "react";

const Insight: React.FC = () => {
  return (
    <div className="p-8">
      <h1>Insights</h1>
    </div>
  );
};

export default Insight;
