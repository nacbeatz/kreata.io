
import React from "react";

const Notification: React.FC = () => {
  return (
    <div className="p-8">
      <h1>Notifications</h1>
    </div>
  );
};

export default Notification;
