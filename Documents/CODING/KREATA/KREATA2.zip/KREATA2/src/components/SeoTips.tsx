
import React from "react";

const SeoTips: React.FC = () => {
  return (
    <div className="p-8">
      <h1>Seo Tips</h1>
    </div>
  );
};

export default SeoTips;
